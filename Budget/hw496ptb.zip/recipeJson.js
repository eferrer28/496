db.recipes.insert([
{
	
	name: 'Historical Fiction',
	ingredients: 'Chicken, cheese, kidney beans',
	url: 'http://ketokarma.com/keto-chili/'
},

{
	
	name: 'Dragon Noodles',
	ingredients: 'Noodles',
	url: 'http://www.budgetbytes.com/2012/08/spicy-noodles/'
},

{
	
	name: 'Tikka masala',
	ingredients: 'Chicken, sauce',
	url: 'www.budgetbytes.com/2015/12/slow-cooker-chicken-tikka-masala'
}

])
