db.users.insert([
{
	
	name: 'Eric Ferrer',
	email: 'ferrere@oregonstate.edu',
	budget: 500,
    logs: [ObjectId("580daae142cc3219d19f4a2c"), ObjectId("580da5fc122c2bb191d06d59")]
}

])