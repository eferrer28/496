db.logs.insert([
{
	foodName: 'Chicken',
	price: 5,
	budgetFriendly: true,
	paleo: true,
    recipe: [ObjectId("580d66b77d3a60151fc30e85"), ObjectId("580a8712d75e8f4ede7e41cb"),ObjectId("5809647d5b9d664d3ec13384")]
},
    
{
	foodName: 'beef',
	price: 2,
	budgetFriendly: true,
	paleo: true,
    recipe: [ObjectId("5809647d5b9d664d3ec13383"), ObjectId("580c0aa3b58e52704ede057c")]
}

])